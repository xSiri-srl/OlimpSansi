<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Orden de Pago</title>
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            margin: 40px;
            font-size: 13px;
            line-height: 1.5;
        }

        .text-center { text-align: center; }
        .text-end { text-align: right; }
        .mt-4 { margin-top: 1.5rem; }
        .mb-4 { margin-bottom: 1.5rem; }
        .mb-3 { margin-bottom: 1rem; }

        h4, h5, h6 {
            margin: 0;
            line-height: 1.2;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1.5rem;
        }

        table, th, td {
            border: 1px solid #000;
        }

        th, td {
            padding: 8px;
            font-size: 13px;
        }

        .firma {
            margin-top: 50px;
        }

        .footer {
            margin-top: 40px;
            text-align: center;
            font-size: 12px;
            color: #555;
        }

        .section-label {
            font-weight: bold;
        }
    </style>
</head>
<body>

    <!-- Encabezado -->
    <div class="text-center mb-4">
        <h4>UNIVERSIDAD MAYOR DE SAN SIMÓN</h4>
        <h6>DIRECCION ADMINISTRATIVA Y FINANCIERA</h6>
    </div>

    <!-- Orden de Pago -->
    <h4 class="mb-3">Orden de Pago: 0000<?php echo e($ordenPago->id); ?></h4>

    <!-- Unidad -->
    <p><span class="section-label">Emitido por la Unidad:</span><br>
        Comité de las Olimpiadas Científicas San Simón, Facultad de Ciencias y Tecnología
    </p>

    <!-- Responsable -->
    <p><span class="section-label">Responsable:</span><br>
        <?php if($ordenPago->responsable): ?>
            <?php echo e($ordenPago->responsable->nombre); ?> <?php echo e($ordenPago->responsable->apellido_pa); ?> <?php echo e($ordenPago->responsable->apellido_ma); ?>

            (CI: <?php echo e($ordenPago->responsable->ci); ?><?php echo e($ordenPago->responsable->complemento ? ' ' . $ordenPago->responsable->complemento : ''); ?>)
        <?php else: ?>
            No registrado
        <?php endif; ?>
    </p>

    <!-- Fecha -->
    <p><span class="section-label">Fecha de Emisión:</span> <?php echo e(now()->format('d/m/Y')); ?></p>

    <!-- Tabla de detalles -->
    <table>
        <thead>
            <tr class="text-center">
                <th>Cantidad</th>
                <th>Concepto</th>
                <th>Precio Unitario (Bs)</th>
                <th>Subtotal (Bs)</th>
            </tr>
        </thead>
        <tbody>
            <tr class="text-center">
                <td><?php echo e($ordenPago->contarInscripciones()); ?></td>
                <td>Inscripción de estudiante(s) para olimpiada asociado al codigo de preinscripcion <?php echo e($ordenPago->codigo_generado); ?></td>
                <td>16</td>
                <td><?php echo e($ordenPago->contarInscripciones()*16); ?></td>
            </tr>
        </tbody>
        <tfoot>
            <tr class="text-end">
                <th colspan="3">Total (Bs):</th>
                <th class="text-center"><?php echo e($ordenPago->contarInscripciones()*16); ?></th>
            </tr>
        </tfoot>
    </table>
    <?php
    $numero = $ordenPago->contarInscripciones() * 16;
    ?>
    <p><span class="section-label">La suma de:</span> <?php echo e(mostrarOrdenPago($numero)); ?> 00/100 BOLIVIANOS </p>
    <!-- Firma -->
    <div class="firma">
        <p>
            <strong>Responsable de Pago:</strong><br>
            <?php echo e($ordenPago->responsable->nombre ?? 'No registrado'); ?> <?php echo e($ordenPago->responsable->apellido_pa ?? ''); ?> <?php echo e($ordenPago->responsable->apellido_ma ?? ''); ?>

        </p>
        <p>
            <strong>Firma:</strong> ___________________________
        </p>
    </div>

    <!-- Pie de página -->
    <div class="footer">
        Cochabamba, <?php echo e(now()->format('d/m/Y')); ?>

    </div>

</body>
</html>
<?php /**PATH C:\xampp2\htdocs\OlimpSansi\TisOlimpSansi_BackEnd\resources\views/pdf/orden_pago.blade.php ENDPATH**/ ?>